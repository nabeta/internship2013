#!/usr/bin/php

<?php

require_once 'HTTP/Request2.php';

$send = file_get_contents( $argv[1]); 
try {
    $req = new HTTP_Request2( "http://amaayo.nims.go.jp:8080/pubman/faces/sword-app/deposit?collection=escidoc:3001", HTTP_Request2::METHOD_PUT);
    $req-> setAuth( "pubman_depositor", "admin", HTTP_REQUEST2::AUTH_BASIC);
    $req->setMethod( HTTP_Request2::METHOD_POST);
    $req-> setHeader( 'Content-Type: application/zip');
    $req-> setHeader( 'X-Packaging: http://purl.org/escidoc/metadata/schemas/0.1/publication');
    $req-> setHeader( 'X-Verbose: True');
    $res = $req->setBody( $send);
    $res = $req->send();
    echo $res->getBody();
 
} catch (HTTP_Request2_Exception $e) {
    die($e->getMessage());
} catch (Exception $e) {
    die($e->getMessage());
}
?>
